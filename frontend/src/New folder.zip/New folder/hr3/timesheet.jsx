import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectTrigger,
  SelectContent,
  SelectItem,
  SelectValue,
} from "@/components/ui/select";
import { TimesheetDialog } from "@/components/hr3/timesheetDialog";
import TermsDialog from "@/components/hr3/TermsDialog";
import { useState, useEffect } from "react";
import axios from "axios";
import { hr3 } from "@/api/hr3";

// Default fallback data
const defaultData = [
  { id: 1, employeeName: "John Doe", department: "IT", date: "2023-01-01", status: "Pending", timeIn: "08:00", breakIn: "12:00", breakOut: "13:00", timeOut: "17:00", total: "8:00" },
  { id: 2, employeeName: "Jane Smith", department: "HR", date: "2023-01-01", status: "Approved", timeIn: "08:00", breakIn: "12:00", breakOut: "13:00", timeOut: "17:00", total: "8:00" },
  { id: 3, employeeName: "Bob Lee", department: "Finance", date: "2023-01-02", status: "Pending", timeIn: "09:00", breakIn: "12:00", breakOut: "13:00", timeOut: "18:00", total: "8:00" },
];

// Helper: group unique employees
function getUniqueEmployees(data) {
  return data.reduce((acc, current) => {
    const exists = acc.find((item) => item.employeeName === current.employeeName);
    return exists ? acc : acc.concat([current]);
  }, []);
}

export default function Timesheet() {
  const [data, setData] = useState([]);
  const [showAllRecords, setShowAllRecords] = useState(false);
  const [currentEmployee, setCurrentEmployee] = useState(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [openTermsDialog, setOpenTermsDialog] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  const [dialogMode, setDialogMode] = useState("view"); // "view" | "edit"

  // Fetch data from backend
  useEffect(() => {
    const fetchTimesheet = async () => {
      try {
        const response = await axios.get(hr3.backend.api.timesheet);
        let records = [];

        if (Array.isArray(response.data)) {
          records = response.data;
        } else if (response.data && Array.isArray(response.data.data)) {
          records = response.data.data;
        }

        const mapped = records.map((r) => ({
          id: r.id,
          employeeName: r.employeeName || "Unknown",
          department: r.department || "N/A",
          date: r.work_date || new Date().toISOString().split("T")[0],
          status: r.status || "Pending",
          timeIn: r.start_time || "00:00",
          breakIn: r.break_in || "12:00",
          breakOut: r.break_out || "13:00",
          timeOut: r.end_time || "00:00",
          total: r.total_hours ? `${r.total_hours}:00` : "0:00",
        }));

        setData(mapped.length > 0 ? mapped : defaultData);
      } catch (error) {
        console.error("Error fetching timesheet:", error);
        setData(defaultData);
      }
    };

    fetchTimesheet();
  }, []);

  const uniqueEmployees = getUniqueEmployees(data);

  const handleApprove = (row) => {
    setData((prev) =>
      prev.map((item) =>
        item.id === row.id ? { ...item, status: "Approved" } : item
      )
    );
  };

  // Combined filters
  const filteredData = (showAllRecords
    ? data.filter((row) => row.employeeName === currentEmployee?.employeeName)
    : uniqueEmployees
  ).filter((row) => {
    const matchesSearch = row.employeeName
      .toLowerCase()
      .includes(searchQuery.toLowerCase());
    const matchesDept =
      departmentFilter === "All" || row.department === departmentFilter;
    const matchesStatus =
      statusFilter === "All" || row.status === statusFilter;
    return matchesSearch && matchesDept && matchesStatus;
  });

  const departments = ["All", ...new Set(data.map((r) => r.department))];
  const statuses = ["All", "Pending", "Approved"];

  return (
    <div className="px-4 -mt-5">
      <h1 className="text-2xl font-bold mb-4">Employee Timesheet</h1>

      {/* 🔍 Filters Section */}
      <div className="flex flex-col md:flex-row flex-wrap gap-3 mb-4 items-center">
        <Input
          placeholder="Search by employee name..."
          className="md:w-1/3"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />

        <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
          <SelectTrigger className="md:w-1/4">
            <SelectValue placeholder="Filter by Department" />
          </SelectTrigger>
          <SelectContent>
            {departments.map((dept) => (
              <SelectItem key={dept} value={dept}>
                {dept}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="md:w-1/4">
            <SelectValue placeholder="Filter by Status" />
          </SelectTrigger>
          <SelectContent>
            {statuses.map((status) => (
              <SelectItem key={status} value={status}>
                {status}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {showAllRecords && (
        <div className="flex justify-between items-center mb-3">
          <h2 className="text-lg font-semibold">
            Viewing all records for {currentEmployee?.employeeName}
          </h2>
          <Button variant="outline" onClick={() => setShowAllRecords(false)}>
            Back
          </Button>
        </div>
      )}

      {/* 🧾 Table */}
      <div className="overflow-auto rounded-lg border min-h-[650px] max-h-[800px]">
        <Table className="w-full">
          <TableCaption>Timesheet Records</TableCaption>
          <TableHeader>
            <TableRow className="bg-gray-100">
              <TableHead className="text-center">#</TableHead>
              <TableHead className="text-center">Name</TableHead>
              <TableHead className="text-center">Department</TableHead>
              <TableHead className="text-center">Date</TableHead>
              <TableHead className="text-center">Time In</TableHead>
              <TableHead className="text-center">Break In</TableHead>
              <TableHead className="text-center">Break Out</TableHead>
              <TableHead className="text-center">Time Out</TableHead>
              <TableHead className="text-center">Status</TableHead>
              <TableHead className="text-center">Action</TableHead>
            </TableRow>
          </TableHeader>

          <TableBody>
            {filteredData.length === 0 ? (
              <TableRow>
                <TableCell
                  colSpan={10}
                  className="text-center text-gray-500 py-5"
                >
                  No records found.
                </TableCell>
              </TableRow>
            ) : (
              filteredData.map((row) => (
                <TableRow key={row.id}>
                  {/* Timesheet Dialog */}
                  <TimesheetDialog
                    employee={
                      showAllRecords
                        ? data.filter((r) => r.employeeName === row.employeeName)
                        : row
                    }
                    mode={dialogMode}
                    open={openDialog && selectedEmployee?.id === row.id}
                    onOpenChange={setOpenDialog}
                  />

                  <TableCell>{row.id}</TableCell>
                  <TableCell>{row.employeeName}</TableCell>
                  <TableCell>{row.department}</TableCell>
                  <TableCell>{row.date}</TableCell>
                  <TableCell>{row.timeIn}</TableCell>
                  <TableCell>{row.breakIn}</TableCell>
                  <TableCell>{row.breakOut}</TableCell>
                  <TableCell>{row.timeOut}</TableCell>
                  <TableCell>{row.status}</TableCell>
                  <TableCell className="text-center space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setSelectedEmployee(row);
                        setDialogMode("view");
                        setOpenDialog(true);
                        setCurrentEmployee(row);
                        setShowAllRecords(true);
                      }}
                    >
                      View
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setSelectedEmployee(row);
                        setDialogMode("edit");
                        setOpenDialog(true);
                      }}
                    >
                      Edit
                    </Button>
                    <Button
                      className="mx-1"
                      variant="outline"
                      size="sm"
                      onClick={() => handleApprove(row)}
                    >
                      Approve
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      <div className="w-full justify-center flex">
        <p
          className="text-sm text-blue-500 py-5 cursor-pointer"
          onClick={() => setOpenTermsDialog(true)}
        >
          Terms & Conditions
        </p>
      </div>

      <TermsDialog open={openTermsDialog} onOpenChange={setOpenTermsDialog} />
    </div>
  );
}
